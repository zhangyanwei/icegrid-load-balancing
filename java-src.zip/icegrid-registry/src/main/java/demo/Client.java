package demo;

import java.util.Arrays;

public class Client
{
    public static void main(String[] args)
    {
        try(com.zeroc.Ice.Communicator communicator = com.zeroc.Ice.Util.initialize(args))
        {
            com.zeroc.Ice.ObjectPrx base = communicator.stringToProxy("Printer@PrinterAdapter");
            demo.PrinterPrx printer = demo.PrinterPrx.checkedCast(base);
            if(printer == null)
            {
                throw new Error("Invalid proxy");
            }

            String givenMessage = Arrays.stream(args)
					.filter(arg -> arg.startsWith("-Message=")).findFirst()
					.map(message -> message.substring(message.indexOf("=") + 1)).orElse("Hello !");
			printer.print(String.format("Timestamp: %s - %s", System.currentTimeMillis(), givenMessage));
        }
    }
}